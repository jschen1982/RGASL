A Radial Basis Function-Based Graph Attention Network with Squeeze Loss Optimization for Link Prediction
==========

This repo contains the *PyTorch* code for the paper A Radial Basis Function-Based Graph Attention Network with Squeeze Loss Optimization for Link Prediction. 

This article/code introduces a radial basis function-based graph attention network  with squeeze loss (RGASL), which is used to link prediction tasks.
Two improvements were introduced in the model, including the similarity function based on RBF and the optimization strategy based on the squeeze loss function. 
RBF function can map nodes into vector space and express link features with Euclidean distance. The squeeze loss function can adjust the loss according to the performance of the sample in training, 
adjust the importance of the sample in training and optimize the training strategy. Compared with various baseline models, RGASL achieves good performance on multiple datasets, but has limitations in processing dense or large graphs.

See below for an overview of the model architecture:

![RGASL Architecture](fig/architecture.png "RGASL Architecture")

## Requirements

- Python 3 (tested on 3.9.12)
- PyTorch (tested on 1.12.1)
- numpy (tested on 1.22.3)
- scipy (tested on 1.9.1)



## Training

To train a radial basis function-based graph attention network with squeeze loss optimization (RGASL) model, run:
```
python train.py --dataset Cora --epochs 10000 --dropout 0.3 --lr 0.01 --Beta 0.3
```

For details on the selection of other datasets, please refer to `data/`.

For details on the use of other parameters, please refer to `train.py`.

