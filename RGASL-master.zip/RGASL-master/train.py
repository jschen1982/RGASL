from __future__ import division
from __future__ import print_function

import os
import glob
import time
import random
import argparse
import numpy as np
import torch
import torch.nn.functional as F
import torch.optim as optim

from utils import load_data, compute_AUC, make_one_hot
from models import RGASL

# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=False, help='Disables CUDA training.')
parser.add_argument('--seed', type=int, default=72, help='Random seed.')
parser.add_argument('--epochs', type=int, default=10000, help='Number of epochs to train.')
parser.add_argument('--lr', type=float, default=0.01, help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4, help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=4, help='Number of hidden units.')
parser.add_argument('--nb_heads', type=int, default=4, help='Number of head attentions.')
parser.add_argument('--gamma_dimension', type=int, default=8, help='Dimension of learnable weight matrices gamma.')
parser.add_argument('--dropout', type=float, default=0.3, help='Dropout rate (1 - keep probability).')
parser.add_argument('--alpha', type=float, default=0.5, help='Alpha for the leaky_relu.')
parser.add_argument('--patience', type=int, default=100, help='Patience')
parser.add_argument('--Beta', type=float, default=0.3, help='Beta')
parser.add_argument('--dataset', type=str, default='Cora')

args = parser.parse_args()
dataset = args.dataset
args.cuda = not args.no_cuda and torch.cuda.is_available()
beta = args.Beta

random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
if args.cuda:
    torch.cuda.manual_seed(args.seed)

# Load data
t_total = time.time()
adj, features, labels_train, labels_val, labels_test, idx_train, idx_val, idx_test = load_data(dataset)


# Model and optimizer
model = RGASL(nfeat=features.shape[1],
                nhid=args.hidden, 
                ndimension=args.gamma_dimension,
                dropout=args.dropout, 
                nheads=args.nb_heads, 
                alpha=args.alpha)
optimizer = optim.Adam(model.parameters(), 
                       lr=args.lr, 
                       weight_decay=args.weight_decay)

# Initialization
pre_output = torch.zeros((labels_train.shape[0]))
labels_one_hot = make_one_hot(labels_train)


# Cuda
if args.cuda:
    model.cuda()
    adj = adj.cuda()
    features = features.cuda()
    pre_output = pre_output.cuda()
    labels_one_hot = labels_one_hot.cuda()
    idx_train = idx_train.cuda()
    labels_train = labels_train.cuda()
    idx_test = idx_test.cuda()
    labels_test = labels_test.cuda()
    idx_val = idx_val.cuda()
    labels_val = labels_val.cuda()





def train(epoch, labels_one_hot, pre_output, idx_train_1, idx_train_2, idx_val_1, idx_val_2):
    t = time.time()
    model.train()
    optimizer.zero_grad()
    output_bi, output_tri, output_val = model(features, adj, idx_train_1, idx_train_2, idx_val_1, idx_val_2)

    if epoch == 0:
        loss_train = torch.mean(F.binary_cross_entropy(output_bi, labels_train), axis=0)
        loss_val = F.binary_cross_entropy(output_val, labels_val)

    # Squeeze loss optimization
    else:
        loss_train = F.binary_cross_entropy(output_bi, labels_train) + beta * F.triplet_margin_loss(output_tri, labels_one_hot, pre_output)
        loss_train = torch.mean(loss_train, axis=0)
        loss_val = F.binary_cross_entropy(output_val, labels_val)

    loss_train.backward()
    optimizer.step()

    print('Epoch: {:04d}'.format(epoch+1),
          'loss_train: {:.4f}'.format(loss_train.data.item()),
          'loss_val: {:.4f}'.format(loss_val.data.item()),
          'time: {:.4f}s'.format(time.time() - t))

    return loss_val.data.item(), output_tri.detach()


def test():
    model.eval()
    output_test, output_tri, output_val = model(features, adj, idx_test[:, 0], idx_test[:, 1], idx_val[:, 0], idx_val[:, 1])
    loss_test = F.binary_cross_entropy(output_test, labels_test)
    auc = compute_AUC(output_test)

    print("Test set results:",
      "loss= {:.4f}".format(loss_test.data),
      "auc= {:.4f}".format(auc))


# Train model
loss_values = []
bad_counter = 0
best = args.epochs + 1
best_epoch = 0
for epoch in range(args.epochs):
    loss, pre_output = train(epoch, labels_one_hot, pre_output, idx_train[:, 0], idx_train[:, 1], idx_val[:, 0], idx_val[:, 1])
    loss_values.append(loss)

    torch.save(model.state_dict(), '{}.pkl'.format(epoch))
    if loss_values[-1] < best:
        best = loss_values[-1]
        best_epoch = epoch + 1
        bad_counter = 0
    else:
        bad_counter += 1

    if bad_counter == args.patience:
        break

    files = glob.glob('*.pkl')
    for file in files:
        epoch_nb = int(file.split('.')[0])
        if epoch_nb < best_epoch:
            os.remove(file)

files = glob.glob('*.pkl')
for file in files:
    epoch_nb = int(file.split('.')[0])
    if epoch_nb > best_epoch:
        os.remove(file)

print("Optimization Finished!")
print("Total time elapsed: {:.4f}s".format(time.time() - t_total))

# Restore best model
print('Loading {}th epoch'.format(best_epoch))
model.load_state_dict(torch.load('{}.pkl'.format(best_epoch)))

# Testing
test()

