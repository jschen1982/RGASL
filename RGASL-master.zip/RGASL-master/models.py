import torch
import torch.nn as nn
from layers import GraphAttentionLayer
import torch.nn.functional as F


class RGASL(nn.Module):
    def __init__(self, nfeat, nhid, ndimension, dropout, alpha, nheads):
        super(RGASL, self).__init__()
        self.dropout = dropout

        # Multiple attention mechanism
        self.attentions = [GraphAttentionLayer(nfeat, nhid, dropout=dropout, alpha=alpha, concat=True) for _ in range(nheads)]
        for i, attention in enumerate(self.attentions):
            self.add_module('attention_{}'.format(i), attention)

        # The second layer of attention
        self.out_att = GraphAttentionLayer(nhid * nheads, ndimension, dropout=dropout, alpha=alpha, concat=False)
        # Parameter initialization
        self.gamma_1 = nn.Parameter(torch.ones(size=(ndimension, 1)))
        self.gamma_2 = nn.Parameter(torch.ones(size=(ndimension, 2)))

    def forward(self, x, adj, idx_train_1, idx_train_node_2, idx_val_1, idx_val_2):
        # Calculate node features
        x = F.dropout(x, self.dropout, training=self.training)
        x = torch.cat([att(x, adj) for att in self.attentions], dim=1)
        x = F.dropout(x, self.dropout, training=self.training)
        x = F.elu(self.out_att(x, adj))
        # Computing link features based on RBF similarity function
        rmb_train = torch.exp(-F.relu(torch.mm((x[idx_train_1] - x[idx_train_node_2]).pow(2), self.gamma_1)))  # Used to calculate binary loss of training set
        rmc_train = torch.exp(-F.relu(torch.mm((x[idx_train_1] - x[idx_train_node_2]).pow(2), self.gamma_2)))  # Used to calculate triplet loss of training set
        rmb_val = torch.exp(-F.relu(torch.mm((x[idx_val_1] - x[idx_val_2]).pow(2), self.gamma_1)))  # Used to calculate binary loss of validation set
        return torch.squeeze(rmb_train, 1), rmc_train, torch.squeeze(rmb_val, 1)

