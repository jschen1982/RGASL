import numpy as np
import scipy.sparse as sp
import torch



def load_data(dataset, path="./data/"):
    path += (dataset + '/')
    print('Loading {} dataset...'.format(dataset))

    if dataset == "Cora":
        nodes_num = 2708
        edges_num = 5429
    elif dataset == "Yeast":
        nodes_num = 2375
        edges_num = 11693
    elif dataset == "Celegans":
        nodes_num = 297
        edges_num = 2148
    elif dataset == "Citeseer":
        nodes_num = 3305
        edges_num = 4732
    elif dataset == "Sexual":
        nodes_num = 288
        edges_num = 291

    # Load data
    features = np.load("{}{}_features.npy".format(path, dataset))
    idx_train = torch.load("{}{}_train_edges.pt".format(path, dataset))
    idx_val = torch.load("{}{}_validation_edges.pt".format(path, dataset))
    idx_test = torch.load("{}{}_test_edges.pt".format(path, dataset))
    edges = np.genfromtxt("{}{}_edges_AD.txt".format(path, dataset), dtype=np.int32)


    # Adjacency matrix
    adj = sp.coo_matrix((np.ones(edges.shape[0]), (edges[:, 0], edges[:, 1])), shape=(nodes_num, nodes_num),
                        dtype=np.float32)
    adj = adj + adj.T.multiply(adj.T > adj) - adj.multiply(adj.T > adj)
    adj = normalize_adj(adj + sp.eye(adj.shape[0]))

    adj = torch.FloatTensor(np.array(adj.todense()))
    features = torch.FloatTensor(features)


    idx_train = torch.LongTensor(idx_train)
    idx_test = torch.LongTensor(idx_test)
    idx_val = torch.LongTensor(idx_val)

    train_len = int(len(idx_train) / 2)
    val_len = int(len(idx_val) / 2)
    test_len = int(len(idx_test) / 2)

    # Labels
    labels_train = torch.cat(
        [torch.ones(train_len, dtype=torch.float32), torch.zeros(train_len, dtype=torch.float32)], dim=0)
    labels_val = torch.cat(
        [torch.ones(val_len, dtype=torch.float32), torch.zeros(val_len, dtype=torch.float32)],
        dim=0)
    labels_test = torch.cat(
        [torch.ones(test_len, dtype=torch.float32), torch.zeros(test_len, dtype=torch.float32)], dim=0)



    return adj, features, labels_train, labels_val, labels_test, idx_train, idx_val, idx_test


def normalize_adj(mx):
    # Row-normalize sparse matrix
    rowsum = np.array(mx.sum(1))
    r_inv_sqrt = np.power(rowsum, -0.5).flatten()
    r_inv_sqrt[np.isinf(r_inv_sqrt)] = 0.
    r_mat_inv_sqrt = sp.diags(r_inv_sqrt)
    return mx.dot(r_mat_inv_sqrt).transpose().dot(r_mat_inv_sqrt)



def make_one_hot(labels):
    # Make one-hot labels
    one_hot = torch.zeros(labels.shape[0], 2)
    for i in range(len(labels)):
        if labels[i] == 1:
            one_hot[i][1] = 1
        else:
            one_hot[i][0] = 1
    return one_hot



def compute_AUC(output):
    # Compute AUC value
    num = int(len(output) / 2)
    auc = 0
    for i in range(num):
        if output[i] > output[i + num]:
            auc += 1
        elif output[i] == output[i + num]:
            auc += 0.5
        else:
            auc += 0
    auc /= num
    return auc



